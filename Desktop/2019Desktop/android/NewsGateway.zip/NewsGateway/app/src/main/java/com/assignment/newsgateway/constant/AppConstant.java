package com.assignment.newsgateway.constant;


public interface AppConstant {
    String API_KEY = "9140722684dd4ab7849d9441b1498830";

    String ACTION_NEWS_STORY = "ACTION_NEWS_STORY";
    String ACTION_MSG_TO_SERVICE = "ACTION_MSG_TO_SERVICE";
}
